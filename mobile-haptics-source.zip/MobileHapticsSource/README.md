# Mobile Haptics — Minecraft 1.21.11 Fabric

Client-side haptic feedback for Android Minecraft Java launchers that expose the
`DALVIK_JAVAVM` and `DALVIK_APPLICATION` native bridge environment variables.

The mod vibrates after a successful block break and after an accepted block interaction.
Commands:

- `/mobilehaptics on`
- `/mobilehaptics off`
- `/mobilehaptics test`
- `/mobilehaptics break <duration_ms> <amplitude_1-255>`
- `/mobilehaptics place <duration_ms> <amplitude_1-255>`
- `/mobilehaptics join-test true|false`
- `/mobilehaptics reload`

A test vibration is also bound to H for desktop testing.
