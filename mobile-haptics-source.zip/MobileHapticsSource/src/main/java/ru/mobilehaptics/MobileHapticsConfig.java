package ru.mobilehaptics;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

public final class MobileHapticsConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("mobilehaptics.json");

    public static boolean enabled = true;
    public static int breakDurationMs = 35;
    public static int breakAmplitude = 160;
    public static int placeDurationMs = 22;
    public static int placeAmplitude = 125;
    public static int testDurationMs = 70;
    public static int testAmplitude = 200;
    public static boolean testOnWorldJoin = false;

    private MobileHapticsConfig() {}

    public static void load() {
        if (!Files.exists(FILE)) {
            save();
            return;
        }
        try (Reader reader = Files.newBufferedReader(FILE)) {
            Data d = GSON.fromJson(reader, Data.class);
            if (d != null) {
                enabled = d.enabled;
                breakDurationMs = clamp(d.breakDurationMs, 1, 1000);
                breakAmplitude = clamp(d.breakAmplitude, 1, 255);
                placeDurationMs = clamp(d.placeDurationMs, 1, 1000);
                placeAmplitude = clamp(d.placeAmplitude, 1, 255);
                testDurationMs = clamp(d.testDurationMs, 1, 1000);
                testAmplitude = clamp(d.testAmplitude, 1, 255);
                testOnWorldJoin = d.testOnWorldJoin;
            }
        } catch (Exception ignored) {
            // Keep safe defaults when a malformed config is encountered.
        }
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE)) {
                Data d = new Data();
                d.enabled = enabled;
                d.breakDurationMs = breakDurationMs;
                d.breakAmplitude = breakAmplitude;
                d.placeDurationMs = placeDurationMs;
                d.placeAmplitude = placeAmplitude;
                d.testDurationMs = testDurationMs;
                d.testAmplitude = testAmplitude;
                d.testOnWorldJoin = testOnWorldJoin;
                GSON.toJson(d, writer);
            }
        } catch (IOException ignored) {
        }
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static final class Data {
        boolean enabled = true;
        int breakDurationMs = 35;
        int breakAmplitude = 160;
        int placeDurationMs = 22;
        int placeAmplitude = 125;
        int testDurationMs = 70;
        int testAmplitude = 200;
        boolean testOnWorldJoin = false;
    }
}
