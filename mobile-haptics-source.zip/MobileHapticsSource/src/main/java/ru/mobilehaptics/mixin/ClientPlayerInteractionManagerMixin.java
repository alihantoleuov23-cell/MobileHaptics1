package ru.mobilehaptics.mixin;

import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.mobilehaptics.MobileHapticsConfig;
import ru.mobilehaptics.NativeHaptics;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin {
    @Inject(method = "breakBlock", at = @At("RETURN"))
    private void mobilehaptics$break(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValueZ()) {
            NativeHaptics.vibrate(MobileHapticsConfig.breakDurationMs, MobileHapticsConfig.breakAmplitude);
        }
    }

    @Inject(method = "interactBlock", at = @At("RETURN"))
    private void mobilehaptics$place(net.minecraft.client.network.ClientPlayerEntity player,
                                     net.minecraft.util.Hand hand,
                                     net.minecraft.util.hit.BlockHitResult hitResult,
                                     CallbackInfoReturnable<net.minecraft.util.ActionResult> cir) {
        net.minecraft.util.ActionResult result = cir.getReturnValue();
        if (result != null && result.isAccepted()) {
            NativeHaptics.vibrate(MobileHapticsConfig.placeDurationMs, MobileHapticsConfig.placeAmplitude);
        }
    }
}
