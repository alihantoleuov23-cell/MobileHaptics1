package ru.mobilehaptics;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class MobileHapticsClient {
    public static final String MOD_ID = "mobilehaptics";
    private static KeyBinding settingsKey;

    private MobileHapticsClient() {}

    public static void onInitializeClient() {
        MobileHapticsConfig.load();
        NativeHaptics.init();

        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mobilehaptics.test",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H,
                "category.mobilehaptics"
        ));

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            if (MobileHapticsConfig.enabled && MobileHapticsConfig.testOnWorldJoin) {
                NativeHaptics.vibrate(MobileHapticsConfig.testDurationMs, MobileHapticsConfig.testAmplitude);
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> registerCommands(dispatcher));
        ClientTickEvents.END_CLIENT_TICK.register(MobileHapticsClient::clientTick);
    }

    private static void registerCommands(com.mojang.brigadier.CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(com.mojang.brigadier.builder.LiteralArgumentBuilder.<FabricClientCommandSource>literal("mobilehaptics")
                .then(com.mojang.brigadier.builder.LiteralArgumentBuilder.<FabricClientCommandSource>literal("on")
                        .executes(ctx -> { MobileHapticsConfig.enabled = true; MobileHapticsConfig.save(); feedback(ctx, "Mobile Haptics: ON"); return 1; }))
                .then(com.mojang.brigadier.builder.LiteralArgumentBuilder.<FabricClientCommandSource>literal("off")
                        .executes(ctx -> { MobileHapticsConfig.enabled = false; MobileHapticsConfig.save(); feedback(ctx, "Mobile Haptics: OFF"); return 1; }))
                .then(com.mojang.brigadier.builder.LiteralArgumentBuilder.<FabricClientCommandSource>literal("test")
                        .executes(ctx -> { NativeHaptics.vibrate(MobileHapticsConfig.testDurationMs, MobileHapticsConfig.testAmplitude); feedback(ctx, "Test vibration sent"); return 1; }))
                .then(com.mojang.brigadier.builder.LiteralArgumentBuilder.<FabricClientCommandSource>literal("break")
                        .then(com.mojang.brigadier.builder.RequiredArgumentBuilder.<FabricClientCommandSource, Integer>argument("duration", IntegerArgumentType.integer(1, 1000))
                                .then(com.mojang.brigadier.builder.RequiredArgumentBuilder.<FabricClientCommandSource, Integer>argument("amplitude", IntegerArgumentType.integer(1, 255))
                                        .executes(ctx -> {
                                            MobileHapticsConfig.breakDurationMs = IntegerArgumentType.getInteger(ctx, "duration");
                                            MobileHapticsConfig.breakAmplitude = IntegerArgumentType.getInteger(ctx, "amplitude");
                                            MobileHapticsConfig.save();
                                            feedback(ctx, "Break vibration updated");
                                            return 1;
                                        }))))
                .then(com.mojang.brigadier.builder.LiteralArgumentBuilder.<FabricClientCommandSource>literal("place")
                        .then(com.mojang.brigadier.builder.RequiredArgumentBuilder.<FabricClientCommandSource, Integer>argument("duration", IntegerArgumentType.integer(1, 1000))
                                .then(com.mojang.brigadier.builder.RequiredArgumentBuilder.<FabricClientCommandSource, Integer>argument("amplitude", IntegerArgumentType.integer(1, 255))
                                        .executes(ctx -> {
                                            MobileHapticsConfig.placeDurationMs = IntegerArgumentType.getInteger(ctx, "duration");
                                            MobileHapticsConfig.placeAmplitude = IntegerArgumentType.getInteger(ctx, "amplitude");
                                            MobileHapticsConfig.save();
                                            feedback(ctx, "Place vibration updated");
                                            return 1;
                                        }))))
                .then(com.mojang.brigadier.builder.LiteralArgumentBuilder.<FabricClientCommandSource>literal("join-test")
                        .then(com.mojang.brigadier.builder.RequiredArgumentBuilder.<FabricClientCommandSource, Boolean>argument("enabled", BoolArgumentType.bool())
                                .executes(ctx -> {
                                    MobileHapticsConfig.testOnWorldJoin = BoolArgumentType.getBool(ctx, "enabled");
                                    MobileHapticsConfig.save();
                                    feedback(ctx, "Join test updated");
                                    return 1;
                                })))
                .then(com.mojang.brigadier.builder.LiteralArgumentBuilder.<FabricClientCommandSource>literal("reload")
                        .executes(ctx -> { MobileHapticsConfig.load(); feedback(ctx, "Configuration reloaded"); return 1; }))); 
    }

    private static void feedback(com.mojang.brigadier.context.CommandContext<FabricClientCommandSource> ctx, String text) {
        ctx.getSource().sendFeedback(net.minecraft.text.Text.literal(text));
    }

    public static void clientTick(net.minecraft.client.MinecraftClient client) {
        while (settingsKey != null && settingsKey.wasPressed()) {
            NativeHaptics.vibrate(MobileHapticsConfig.testDurationMs, MobileHapticsConfig.testAmplitude);
        }
    }
}
