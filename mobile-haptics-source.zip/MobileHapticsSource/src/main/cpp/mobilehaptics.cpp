#include <jni.h>
#include <cstdint>

namespace {
JavaVM* g_vm = nullptr;
jobject g_application = nullptr;
jclass g_vibrator_class = nullptr;
jobject g_vibrator = nullptr;
jmethodID g_vibrate_effect = nullptr;
jclass g_vibration_effect_class = nullptr;
jmethodID g_create_one_shot = nullptr;

JNIEnv* getEnv() {
    if (!g_vm) return nullptr;
    JNIEnv* env = nullptr;
    if (g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_OK) {
        return env;
    }
    if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return nullptr;
    return env;
}

void clearException(JNIEnv* env) {
    if (env && env->ExceptionCheck()) env->ExceptionClear();
}
}

extern "C" JNIEXPORT void JNICALL
Java_ru_mobilehaptics_NativeHaptics_nativeInit(JNIEnv* env, jclass, jlong vmPtr, jlong appPtr) {
    g_vm = reinterpret_cast<JavaVM*>(static_cast<uintptr_t>(vmPtr));
    jobject application = reinterpret_cast<jobject>(static_cast<uintptr_t>(appPtr));
    if (!g_vm || !application) return;

    if (g_application) {
        env->DeleteGlobalRef(g_application);
        g_application = nullptr;
    }
    g_application = env->NewGlobalRef(application);
    if (!g_application) return;

    jclass appClass = env->GetObjectClass(g_application);
    jclass contextClass = env->FindClass("android/content/Context");
    if (!appClass || !contextClass) { clearException(env); return; }

    jfieldID vibratorServiceField = env->GetStaticFieldID(contextClass, "VIBRATOR_SERVICE", "Ljava/lang/String;");
    jmethodID getSystemService = env->GetMethodID(contextClass, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
    if (!vibratorServiceField || !getSystemService) { clearException(env); return; }

    jobject serviceName = env->GetStaticObjectField(contextClass, vibratorServiceField);
    jobject vibrator = env->CallObjectMethod(g_application, getSystemService, serviceName);
    clearException(env);
    if (!vibrator) return;

    g_vibrator = env->NewGlobalRef(vibrator);
    g_vibrator_class = reinterpret_cast<jclass>(env->NewGlobalRef(env->GetObjectClass(vibrator)));

    g_vibration_effect_class = reinterpret_cast<jclass>(env->NewGlobalRef(env->FindClass("android/os/VibrationEffect")));
    clearException(env);
    if (!g_vibration_effect_class) return;

    g_create_one_shot = env->GetStaticMethodID(g_vibration_effect_class, "createOneShot", "(JI)Landroid/os/VibrationEffect;");
    g_vibrate_effect = env->GetMethodID(g_vibrator_class, "vibrate", "(Landroid/os/VibrationEffect;)V");
    clearException(env);
}

extern "C" JNIEXPORT void JNICALL
Java_ru_mobilehaptics_NativeHaptics_nativeVibrate(JNIEnv* envFromJava, jclass, jint durationMs, jint amplitude) {
    if (!g_vibrator || !g_create_one_shot || !g_vibrate_effect) return;
    JNIEnv* env = getEnv();
    if (!env) return;

    jobject effect = env->CallStaticObjectMethod(g_vibration_effect_class,
                                                  g_create_one_shot,
                                                  static_cast<jlong>(durationMs),
                                                  static_cast<jint>(amplitude));
    if (env->ExceptionCheck()) { env->ExceptionClear(); return; }
    if (!effect) return;

    env->CallVoidMethod(g_vibrator, g_vibrate_effect, effect);
    clearException(env);
    env->DeleteLocalRef(effect);
}
